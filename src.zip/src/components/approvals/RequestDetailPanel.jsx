import LeaveTypeBadge from './LeaveTypeBadge';
import { getAvatarColor, getInitials } from '../../utils/avatarColor';
import { getEmployeeName, getEmployeeCode } from '../../utils/employee';
import { PaperclipIcon, DownloadIcon, InfoIcon } from '../icons/Icons';
import './RequestDetailPanel.css';

const formatDate = (iso, withTime = false) => {
  if (!iso) return '—';
  const opts = withTime
    ? { day: '2-digit', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' }
    : { day: '2-digit', month: 'short', year: 'numeric', weekday: 'short' };
  return new Date(iso).toLocaleString('en-US', opts);
};

const formatFileSize = (bytes) => {
  if (!bytes) return '';
  const kb = bytes / 1024;
  return kb < 1024 ? `${Math.round(kb)} KB` : `${(kb / 1024).toFixed(1)} MB`;
};

const RequestDetailPanel = ({ detail, loading }) => {
  if (loading) {
    return (
      <div className="request-detail-panel">
        <p className="widget-empty">Loading request details...</p>
      </div>
    );
  }

  if (!detail) {
    return (
      <div className="request-detail-panel">
        <p className="widget-empty">Select a request to view details.</p>
      </div>
    );
  }

  const employeeName = getEmployeeName(detail);
  const color = getAvatarColor(employeeName);
  const employeeCode = getEmployeeCode(detail, detail.userId);

  const handleDownloadAttachment = (attachment) => {
    // Guard for PENDING status - only allow download when attachment is ACTIVE
    if (attachment.uploadStatus === 'PENDING' || attachment.status === 'PENDING') {
      alert('Attachment upload is still in progress. Please wait for it to complete.');
      return;
    }

    // Use the download URL from the attachment (presigned blob-storage URL)
    if (attachment.downloadUrl && attachment.downloadUrl !== '#') {
      window.open(attachment.downloadUrl, '_blank');
    } else {
      alert('Download URL not available for this attachment.');
    }
  };

  return (
    <div className="request-detail-panel">
      <div className="widget-header">
        <h3>Request Details</h3>
      </div>

      <div className="request-detail-employee">
        <span 
          className="request-detail-avatar" 
          style={{ 
            background: detail.avatarUrl ? 'transparent' : color.bg, 
            color: detail.avatarUrl ? 'transparent' : color.fg 
          }}
        >
          {detail.avatarUrl ? (
            <img 
              src={detail.avatarUrl} 
              alt={employeeName} 
              className="request-detail-avatar-image"
              onError={(e) => {
                e.target.style.display = 'none';
                e.target.parentElement.style.background = color.bg;
                e.target.parentElement.style.color = color.fg;
                e.target.parentElement.textContent = getInitials(employeeName);
              }}
            />
          ) : (
            getInitials(employeeName)
          )}
        </span>
        <div>
          <span className="request-detail-name">{employeeName || '—'}</span>
          <span className="request-detail-team">
            {[detail.departmentName, employeeCode].filter(Boolean).join(' · ')}
          </span>
        </div>
      </div>

      <dl className="request-detail-fields">
        <div>
          <dt>Leave Type</dt>
          <dd>
            <LeaveTypeBadge categoryCode={detail.categoryCode} categoryName={detail.categoryName} />
          </dd>
        </div>
        <div>
          <dt>Dates</dt>
          <dd>
            {detail.startDate === detail.endDate
              ? formatDate(detail.startDate)
              : `${formatDate(detail.startDate)} – ${formatDate(detail.endDate)}`}
          </dd>
        </div>
        <div>
          <dt>Total Days</dt>
          <dd>{detail.totalDays}</dd>
        </div>
        <div>
          <dt>Reason</dt>
          <dd>{detail.reason}</dd>
        </div>
        <div>
          <dt>Applied On</dt>
          <dd>{formatDate(detail.appliedAt, true)}</dd>
        </div>
        <div>
          <dt>Reporting Manager</dt>
          <dd>{detail.currentApproverName || '—'}</dd>
        </div>
      </dl>

      {detail.attachments?.length > 0 && (
        <div className="request-detail-section">
          <h4>Attachments</h4>
          <ul className="request-detail-attachments">
            {detail.attachments.map((att) => (
              <li key={att.id}>
                <PaperclipIcon width={14} height={14} />
                <span className="request-detail-attachment-name">{att.fileName}</span>
                <span className="request-detail-attachment-size">{formatFileSize(att.sizeBytes)}</span>
                <button 
                  onClick={() => handleDownloadAttachment(att)}
                  disabled={att.uploadStatus === 'PENDING' || att.status === 'PENDING'}
                  className="request-detail-download"
                  title={att.uploadStatus === 'PENDING' || att.status === 'PENDING' ? 'Upload in progress' : 'Download attachment'}
                >
                  <DownloadIcon width={14} height={14} />
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {detail.approvals?.length > 0 && (
        <div className="request-detail-section">
          <h4>Approval History</h4>
          <ul className="request-detail-timeline">
            {detail.approvals.map((a) => (
              <li key={a.id}>
                <span className="request-detail-timeline-dot" />
                <div>
                  <span className="request-detail-timeline-label">
                    {a.decision === 'REQUESTED' || !a.decision
                      ? 'Requested'
                      : a.decision === 'APPROVED'
                      ? 'Approved'
                      : 'Rejected'}
                    {a.approverName ? ` · ${a.approverName}` : ''}
                  </span>
                  <span className="request-detail-timeline-time">{formatDate(a.decidedAt, true)}</span>
                  {a.comments && <span className="request-detail-timeline-comment">"{a.comments}"</span>}
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default RequestDetailPanel;